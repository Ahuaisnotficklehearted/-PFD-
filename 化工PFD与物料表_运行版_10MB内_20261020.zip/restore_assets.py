"""Restore the offline runtime bundle using Python 3.9+ standard library."""
from pathlib import Path
import hashlib
import json
import tarfile

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'runtime-files.sha256.json').read_text(encoding='utf-8'))
with tarfile.open(root / 'runtime-assets.tar.xz', 'r:xz') as archive:
    members = archive.getmembers()
    if {m.name for m in members} != set(manifest) or len(members) != len(manifest):
        raise ValueError('Archive inventory mismatch')
    for member in members:
        target = (root / member.name).resolve()
        if not member.isfile() or not target.is_relative_to(root):
            raise ValueError('Unsafe archive entry')
        data = archive.extractfile(member).read()
        if hashlib.sha256(data).hexdigest() != manifest[member.name]:
            raise ValueError('Archive content mismatch: ' + member.name)
        if target.exists() and target.read_bytes() != data:
            raise FileExistsError('Existing modified file: ' + str(target))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
print('Restored and SHA256 verified', len(manifest), 'runtime files.')
