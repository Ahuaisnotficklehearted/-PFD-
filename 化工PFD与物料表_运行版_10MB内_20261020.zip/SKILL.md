---
name: chemical-pfd-material-runtime
description: 化工AutoCAD PFD制图与完整物料表运行版，包含全部程序、1678项可调用图库及预览，原始DWG归档单独交付。
---

# 化工 PFD 与物料表运行版

## 首次使用

使用 Python 3.9 或更新版本，在本目录运行 `python restore_assets.py`。脚本仅用标准库恢复2457个运行文件并逐个核对SHA256，不联网下载。随后将 chemical-autocad-drafting 与 material-import-pfd 两个目录并列安装到所用智能体的技能目录。

执行制图前读取 [主技能](chemical-autocad-drafting/SKILL.md)；执行物料表任务读取 [子技能](material-import-pfd/SKILL.md)。需 Windows、AutoCAD；Aspen数据读取需本机Aspen Plus，Python依赖见技能requirements。相关商业软件及许可证未包含。

## 已确认的交付范围

保留全部脚本、1678项可调用图库、SVG浏览预览、研究证据、物料表处理及作者新来信。400份原始DWG和35份同内容外形图副本单独放在《化工PFD_原图参考包_20261020.zip》。单独安装运行版不提供这些原件的浏览与复核。需原件时，将参考包解压到两技能目录的父目录，保持原路径即可补装；运行版不依赖在线资源托管。

作者：阿华。新来信说明打赏费用用于持续优化更新，并声明“非作者严禁用于商业用途售卖等”。完整来信保存在 chemical-autocad-drafting/assets/author/来自作者的一封信.docx。
